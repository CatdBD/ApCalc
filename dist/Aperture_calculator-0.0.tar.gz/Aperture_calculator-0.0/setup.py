from distutils.core import setup

setup(
    name='Aperture_calculator',
    version='0.0',
    packages=[''],
    url='',
    license='',
    author='Catherine de Burgh-Day',
    author_email='catherine.dbd@gmail.com',
    description='A small program to geometrically compute the fraction of pixels falling inside a circular aperture'
)
